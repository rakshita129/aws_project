// File: action.js

function Action(actionType, actionIndizes, actionObject) {
    this.actionType = actionType;
    this.actionIndizes = actionIndizes;
    this.actionObject = actionObject;
}