// File: transformation.js

function Transformation(dx, dy, zoom) {
    this.dx = dx;
    this.dy = dy;
    this.zoom = zoom;
}